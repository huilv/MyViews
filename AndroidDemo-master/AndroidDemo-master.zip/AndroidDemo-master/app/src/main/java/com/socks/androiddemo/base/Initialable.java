package com.socks.androiddemo.base;

/**
 * ��ʼ���ӿ�
 * 
 * @ClassName: Initialable
 * @author ZhaoKaiQiang
 * @date 2015-3-27 ����11:23:11
 */
public interface Initialable {

	void initView();

	void initDate();

}
