package com.socks.androiddemo.ui;

import android.os.Bundle;

import com.socks.androiddemo.R;
import com.socks.androiddemo.base.BaseActivity;

/**
 * Created by zhaokaiqiang on 15/9/7.
 */
public class ShaderActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shader);
    }

}
