package com.socks.androiddemo.ui;

import android.app.Activity;
import android.os.Bundle;

import com.socks.androiddemo.R;

/**
 * Created by zhaokaiqiang on 15/8/16.
 */
public class PointViewActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pointview);
	}

}
