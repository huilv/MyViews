package com.socks.androiddemo.ui;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.socks.androiddemo.R;

public class LoadActivity extends ActionBarActivity {


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_load);


	}

}
