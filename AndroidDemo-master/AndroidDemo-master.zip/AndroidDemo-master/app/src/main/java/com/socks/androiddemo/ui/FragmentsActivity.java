package com.socks.androiddemo.ui;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by zhaokaiqiang on 15/5/18.
 */
public class FragmentsActivity extends ActionBarActivity{

	@Override
	public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
		super.onCreate(savedInstanceState, persistentState);

	}
}
